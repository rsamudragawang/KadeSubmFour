package com.ganargatul.kadesubmfour.model

import com.google.gson.annotations.SerializedName

data class DetailTeamsItems (
    @SerializedName("strTeamBadge")
    val strTeamBadge:String?
)